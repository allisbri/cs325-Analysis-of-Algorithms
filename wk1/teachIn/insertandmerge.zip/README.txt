To run the code for mergesort and insertsort on Flip, type: python3 [filename] 
Example: python3 mergesort.py
		 python3 insertsort.py