To run the code for mincoin on Flip, type: python3 [filename] 
Example: python3 mincoin.py
