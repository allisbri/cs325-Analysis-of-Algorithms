To run the code for stoogesort on Flip, type: python3 [filename] 
Example: python3 stoogesort.py
